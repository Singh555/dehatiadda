<?php
namespace App\Models\AppModels;

require_once app_path() . '/razorpay/Razorpay.php';
use Razorpay\Api\Api;
use App\Helpers\HttpStatus;
use Log;
use DB;
use Auth;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of PaymentGatewayModel
 *
 * @author Apple
 */
class PaymentGatewayModel {
    
    public static function generateTxnId($con){
        Log::info(__CLASS__." :: ".__FUNCTION__." started...");
        $txn_id = false;
        for($i=0; $i<50; $i++){
            $txn_id = self::generateAndValidateTxnId($con);
            if($txn_id){
                break;
            }
        }
        return $txn_id;
    }
    private static function generateAndValidateTxnId(){
        Log::info(__CLASS__." :: ".__FUNCTION__." started...");
        $txn_id = time().rand(100, 999);
        try {
            $data = DB::table('pgateway_txn')->select('id')->where('txn_id', '=', $txn_id)->first();
            if(isset($data->id)){
                return false;
            }
        } catch (PDOException $exc) {
            Log::error(__CLASS__." :: ".__FUNCTION__." Exception :: ".$exc->getMessage());
            return false;
        }
        return $txn_id;
    }
    public static function get_payment_history($student_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started...");
        $data = DB::table('pgateway_txn')->where('student_id', '=', $student_id)->where('status', "SUCCESS")->first();
        return $data;
    }
    public static function get_payment_details($customer_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started...");
        $data = DB::table('pgateway_txn')->where('customer_id', '=', $customer_id)->where('status', "SUCCESS")->orderBy('id', 'desc')->limit(1)->get();
        return $data;
    }
    public static function get_success_payment_txn_id($customer_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started...");
        $data = DB::table('pgateway_txn')->where('customer_id', '=', $customer_id)->where('status', "SUCCESS")->first();
        return $data;
    }
    public static function get_customer_id_by_txn_id($txn_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started...");
        $data = DB::table('pgateway_txn')->where('txn_id', '=', $txn_id)->first();
        return $data;
    }
    public static function get_pending_transaction_by_txn_id($txn_id, $customer_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started... with $txn_id, $customer_id");
        $data = DB::table('pgateway_txn')->where('status', '=', "PENDING")->where('txn_id', '=', $txn_id)->where('customer_id', '=', $customer_id)->first();
        return $data;
    }
    public static function get_pending_transaction_by_txn_id_and_order_id($txn_id, $order_id, $customer_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started...");
        $data = DB::table('pgateway_txn')->where('status', '=', "PENDING")->where('razorpay_order_id', '=', $order_id)->where('txn_id', '=', $txn_id)->where('customer_id', '=', $customer_id)->limit(1)->get();
        return $data;
    }
    private static function update_transaction($customer_id, $user_id, $order_id, $txn_id, $status, $desc, $razorpay_payment_id){
        Log::debug(__CLASS__." :: ".__FUNCTION__." Called on upgrade txn with Customer Id $customer_id and Txn id $txn_id, status $status");
        try
        {
            return DB::table('pgateway_txn')->where('txn_id', '=', $txn_id)->where('customer_id', '=', $customer_id)->where('order_id', '=', $order_id)
            ->update([
              'status' => $status,
              'razorpay_payment_id' => $razorpay_payment_id,
              'description' => $desc,
              'updated_by' => $user_id,
            ]);

        }catch (\PDOException $e){
            Log::error(__CLASS__." :: ".__FUNCTION__." Exception :: ".$e->getMessage());
        }
        return false;
    }
    private static function update_transaction_canceled($customer_id, $user_id, $order_id, $txn_id, $status, $desc, $platform){
        Log::debug(__CLASS__." :: ".__FUNCTION__." Called on upgrade txn with Customer Id $customer_id and Txn id $txn_id, status $status, Platform $platform");
        try
        {
            return DB::table('pgateway_txn')->where('txn_id', '=', $txn_id)->where('customer_id', '=', $customer_id)
            ->where('razorpay_payment_id', '=', $order_id)
            ->update([
              'status' => $status,
              'description' => $desc,
              'updated_by' => $user_id,
            ]);

        }catch (\PDOException $e){
            Log::error(__CLASS__." :: ".__FUNCTION__." Exception :: ".$e->getMessage());
        }
        return false;
    }
    private static function update_order_payment($customer_id, $order_no, $status, $gateway){
        Log::debug(__CLASS__." :: ".__FUNCTION__." Called on upgrade txn with Customer Id $customer_id, status $status");
        try
        {
            return DB::table('orders')->where('order_id', '=', $order_no)->where('customer_id', '=', $customer_id)
            ->update([
              'payment_status' => $status,
              'payment_method' => $gateway,
            ]);

        }catch (\PDOException $e){
            Log::error(__CLASS__." :: ".__FUNCTION__." Exception :: ".$e->getMessage());
        }
        return false;
    }
    public static function updatePaymentCanceled(){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started with customer $customer_id, User Id $user_id");
        $razorpay_order_id = htmlspecialchars(strip_tags(Request::post('order_id')));
        $txn_id = htmlspecialchars(strip_tags(Request::post('txn_id')));
        $desc = htmlspecialchars(strip_tags(Request::post('desc')));
        $platform = htmlspecialchars(strip_tags(Request::post('platform')));
        if(empty($razorpay_order_id)){
            Log::debug(__CLASS__." :: ".__FUNCTION__." Order Id is empty for customer id $customer_id");
            JsonModel::encodeToJson("Order Id is empty !!");
        }
        if(empty($txn_id)){
            Log::debug(__CLASS__." :: ".__FUNCTION__." Txn Id is empty for customer id $customer_id");
            JsonModel::encodeToJson("Txn Id is empty !!");
        }
        Log::debug(__CLASS__." :: ".__FUNCTION__." started with customer id $customer_id, Razorpay Order id $razorpay_order_id, Txn Id - $txn_id");
        try
        {
            $wallet_amount = 0;
            $wallet_refunded = "";
            $order_no = "";
            $pGatewayArray = self::get_pending_transaction_by_txn_id_and_order_id($con, $txn_id, $razorpay_order_id, $customer_id);
            Log::debug(__CLASS__." :: ".__FUNCTION__." count = ".count($pGatewayArray));
            if(is_array($pGatewayArray)){
                if(count($pGatewayArray) > 0){
                    foreach ($pGatewayArray as $obj) {
                        $order_no = $obj->order_no;
                    }
                }
            }
            Log::debug(__CLASS__." :: ".__FUNCTION__." Order No. = $order_no");
            $status = "CANCELLED";
            if(!self::update_transaction_canceled($con, $customer_id, $user_id, $razorpay_order_id, $txn_id, $status, $desc, $platform)){
                Log::error(__CLASS__." :: ".__FUNCTION__." update_transaction_canceled failed !");
            }
            $orderArray = OrderModel::getOrderDetailsById($con, $order_no, $customer_id);
            if(isset($orderArray->id)){
                $wallet_amount = $orderArray->ewallet_amount;
                $wallet_refunded = $orderArray->wallet_refunded;
            }
            Log::debug(__CLASS__." :: ".__FUNCTION__." adding updateOrderStatus !");
            if(!OrderModel::updateOrderStatus($con, $customer_id, $user_id, $txn_id, $order_no, $status, $status)){
                Log::error(__CLASS__." :: ".__FUNCTION__." Order cancellation failed  for customer id $customer_id !");
            }
            Log::debug(__CLASS__." :: ".__FUNCTION__." Wallet amount = $wallet_amount, Wallet refund = $wallet_refunded");
            Log::debug(__CLASS__." :: ".__FUNCTION__." adding increaseOrderedProductQuantity !");
            if(!OrderModel::increaseOrderedProductQuantity($con, $customer_id, $user_id, $order_no, $status)){
                Log::error(__CLASS__." :: ".__FUNCTION__." Payment cancellation failed  for customer id $customer_id. Quantity increase failed !");
            }

            $notify = "N";
            Log::debug(__CLASS__." :: ".__FUNCTION__." adding history !");
            $historyAdd = OrderModel::addOrderHistory($con, $order_no, $customer_id, $user_id, $desc, $notify, $status, $platform);
            if(!$historyAdd){
                Log::error(__CLASS__." :: ".__FUNCTION__." addOrderHistory adding failed !");
            }
            
            
            Log::debug(__CLASS__." :: ".__FUNCTION__." Checking wallet refund !");
            Log::debug(__CLASS__." :: ".__FUNCTION__." Wallet amount $wallet_amount !");
            if($wallet_amount > 0 && $wallet_refunded == "N"){
                // refund wallet
                Log::debug(__CLASS__." :: ".__FUNCTION__." Wallet not refunded, start refund !");
                $user_info = UserModel::getUserDataByUsername($user_id, $con);
                if(isset($user_info->id)){
                    $avl_balance = $user_info->ewallet_balance;
                    $balance_after = $avl_balance + $wallet_amount;
                    $txn_desc = "Refunded by Order CANCELLED";
                    $check_status = WalletModel::checkIfNotCreditedInEwalletAgainstOrder($con, $customer_id, $order_no);
                    if(is_bool($check_status)){
                        Log::debug(__CLASS__." :: ".__FUNCTION__." refund check failed !");
                        JsonModel::encodeToJson("Payment cancellation failed !!!!!!");
                    }
                    if($check_status == "CREDIT_AVAILABLE"){
                        $txn_id = OrderModel::generateTxnId($con);
                        if(WalletModel::creditInEwallet($customer_id, $wallet_amount, $balance_after, $txn_desc, $con, $order_no, $txn_id)){
                            $sql = "update orders set wallet_refunded = 'Y', updated_date = now(), updated_by = '{$user_id}' WHERE order_no = '{$order_no}' and customer_id = '{$customer_id}' and status != 'DELETED'";
                            DatabaseFactory::executeQuery($sql, $con);
                        } else {
                            Log::debug(__CLASS__." :: ".__FUNCTION__." refund failed !");
                            JsonModel::encodeToJson("Payment cancellation failed !!!!");
                        }
                    } else {
                        Log::debug(__CLASS__." :: ".__FUNCTION__." Wallet Already refunded !");
                    }
                } else {
                    Log::error(__CLASS__." :: ".__FUNCTION__." User info getting failed !");
                    JsonModel::encodeToJson("Payment cancellation failed !!!!");
                }
            }
            return returnResponse("Payment cancellation success", HttpStatus::HTTP_OK, HttpStatus::HTTP_SUCCESS);
        }catch (\Exception $e){
            Log::error(__CLASS__." :: ".__FUNCTION__." Exception :: ".$e->getMessage());
        }
        Log::error(__CLASS__." :: ".__FUNCTION__." Payment cancellation failed  for customer id $customer_id ");
        return returnResponse("Payment cancellation failed !!", HttpStatus::HTTP_ERROR);
    }
    private static function initiatePaymentDB($customer_id, $user_id, $order_id, $txn_id, $razorpay_orderid, $amount, $name, $mobile, $email, $platform){
        Log::debug(__CLASS__." :: ".__FUNCTION__." Called with Customer Id $customer_id and Txn id $txn_id and razorpay order id $razorpay_orderid");
        try
        {
            $ip = get_client_ip();
            $user_agent = "";
            return DB::table('pgateway_txn')->insert([
              'txn_id' => $txn_id,
              'customer_id' => $customer_id,
              'order_id' => $order_id,
              'razorpay_order_id' => $razorpay_orderid,
              'name' => $name,
              'mobile' => $mobile,
              'email' => $email,
              'amount' => $amount,
              'platform' => $platform,
              'ip' => $ip,
              'user_agent' => $user_agent,
              'created_by' => $user_id,
          ]);

        } catch (\PDOException $e){
            Log::error(__CLASS__."::".__FUNCTION__." Exception :: ".$e->getMessage());
        }
        return false;
    }
     public static function get_payment_methods_detail_value_by_key($payment_method_id, $key){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started...");
        $data = DB::table('payment_methods_detail')->select('value')
        ->where('key', '=', $key)
        ->where('payment_methods_id', '=', $payment_method_id)->first();
        
        return $data;
    }
    public static function initiatePayment($customer_id, $user_id, $order_id, $txn_id, $name, $mobile, $email_id, $amount, $platform){
        Log::debug(__CLASS__." :: ".__FUNCTION__." started with customer $customer_id, User Id $user_id");
        if(empty($amount)){
            Log::debug(__CLASS__." :: ".__FUNCTION__." Amount is empty for customer id $customer_id");
            return false;
        }
        Log::debug(__CLASS__." :: ".__FUNCTION__." started with customer id $customer_id");
        
        try
        {
            Log::debug(__CLASS__." :: ".__FUNCTION__." Txn Id : $txn_id ");
            $apiKey = "";
            $apiSecret = "";
            $razorpayKey = self::get_payment_methods_detail_value_by_key(2, "RAZORPAY_KEY");
            if(isset($razorpayKey->value)){
                $apiKey = $razorpayKey->value;
            }
            $razorpaySecret = self::get_payment_methods_detail_value_by_key(2, "RAZORPAY_SECRET");
            if(isset($razorpaySecret->value)){
                $apiSecret = $razorpaySecret->value;
            }
            Log::debug(__CLASS__." :: ".__FUNCTION__." Key : $apiKey, Secret : $apiSecret ");
            $api = new Api($apiKey, $apiSecret);
            //
            // We create an razorpay order using orders api
            // Docs: https://docs.razorpay.com/docs/orders
            //
            $orderData = [
                'receipt'         => $order_id,
                'amount'          => $amount*100,
                'currency'        => 'INR',
                'payment_capture' => 1 // auto capture
            ];

            $razorpayOrder = $api->order->create($orderData);
            $razorpayOrderId = $razorpayOrder['id'];
            
            Log::debug(__CLASS__." :: ".__FUNCTION__." Razorpay Order Id : $razorpayOrderId ");
            if(self::initiatePaymentDB($customer_id, $user_id, $order_id, $txn_id, $razorpayOrderId, $amount, $name, $mobile, $email_id, $platform)){
                $data = array(
                    'order_id' => $razorpayOrderId
                );
                return $data;
            }

        }catch (\Exception $e){
            Log::error(__CLASS__." :: ".__FUNCTION__." Exception :: ".$e->getMessage());
        }
        Log::error(__CLASS__." :: ".__FUNCTION__." Payment initiate failed  for customer id $customer_id ");
        return false;
    }
    
    public static function validatePayment($request){
        Log::debug(__CLASS__." :: ".__FUNCTION__." Called");
        $success = false;
        $status = "FAILED";
        $desc = "Payment failed";
        $razorpay_orderId = htmlspecialchars(strip_tags($request->input('razorpay_order_id')));
        $razorpay_payment_id = htmlspecialchars(strip_tags($request->input('razorpay_payment_id')));
        $razorpay_signature = htmlspecialchars(strip_tags($request->input('razorpay_signature')));
        $txnId = htmlspecialchars(strip_tags($request->input('txn_id')));
        $platform = htmlspecialchars(strip_tags($request->input('platform')));
        Log::debug(__CLASS__." :: ".__FUNCTION__." Order Id Received as $razorpay_orderId");
        $customer_id = auth()->user()->id;
        Log::debug(__CLASS__." :: ".__FUNCTION__." Txn Id $txnId,  Customer Id : $customer_id");
        $txnData = self::get_pending_transaction_by_txn_id($txnId, $customer_id);
        
        if(!isset($txnData->id)){
            Log::error(__CLASS__." :: ".__FUNCTION__." Txn Data getting failed");
            return returnResponse("Payment validation failed !!", HttpStatus::HTTP_ERROR);
        }
        $amount = "";
        $razorpay_order_id = ""; $order_id = "";
        $name = ""; $email = ""; $mobile = ""; $txn_status = "";
        if(isset($txnData->razorpay_order_id)){
            $razorpay_order_id = $txnData->razorpay_order_id; 
        }
        if(isset($txnData->order_id)){
            $order_id = $txnData->order_id; 
        }
        if(isset($txnData->amount)){
            $amount = $txnData->amount; 
        }
        if(isset($txnData->name)){
            $name = $txnData->name; 
        }
        if(isset($txnData->email)){
            $email = $txnData->email; 
        }
        if(isset($txnData->mobile)){
            $mobile = $txnData->mobile; 
        }
        if(isset($txnData->status)){
            $txn_status = $txnData->status; 
        }
         Log::debug(__CLASS__." :: ".__FUNCTION__." Razorpay Order Id $razorpay_order_id,  Order Id : $order_id, Txn Status : $txn_status");
        if($txn_status != "PENDING"){
            Log::error(__CLASS__." :: ".__FUNCTION__." Payment status is not pending !");
            return returnResponse("Payment status is not pending !!", HttpStatus::HTTP_ERROR);
        }
        if (empty($razorpay_payment_id) === false)
        {
            $apiKey = "";
            $apiSecret = "";
            $razorpayKey = self::get_payment_methods_detail_value_by_key(2, "RAZORPAY_KEY");
            if(isset($razorpayKey->value)){
                $apiKey = $razorpayKey->value;
            }
            $razorpaySecret = self::get_payment_methods_detail_value_by_key(2, "RAZORPAY_SECRET");
            if(isset($razorpaySecret->value)){
                $apiSecret = $razorpaySecret->value;
            }
            $api = new Api($apiKey, $apiSecret);
            try
            {
                // Please note that the razorpay order ID must
                // come from a trusted source (session here, but
                // could be database or something else)
                $attributes = array(
                    'razorpay_order_id' => $razorpay_order_id,
                    'razorpay_payment_id' => $razorpay_payment_id,
                    'razorpay_signature' => $razorpay_signature
                );

                $api->utility->verifyPaymentSignature($attributes);
                $success = true;
            }
            catch(SignatureVerificationError $e)
            {
                $desc = 'Razorpay Error : ' . $e->getMessage();
            }
        }
        if($success){
            $payment_status = "SUCCESS";
            $desc = "Payment Success";
            if(!self::update_transaction($customer_id, $customer_id, $order_id, $txnId, $payment_status, $desc, $razorpay_payment_id)){
                Log::error(__CLASS__." :: ".__FUNCTION__." Payment validation failed  for customer id $customer_id !");
                return returnResponse("Payment validation failed !!", HttpStatus::HTTP_ERROR);
            }
            $status = "ORDERED";
            if(!Orders::updateOrderStatus($customer_id, $customer_id, $order_id, $status, $payment_status)){
                Log::error(__CLASS__." :: ".__FUNCTION__." Payment validation failed ! status updating failed  for customer id $customer_id !");
                return returnResponse("Payment validation failed !!", HttpStatus::HTTP_ERROR);
            }
            $notify = "N";
            $comment = "Order Placed";
//            OrderModel::addOrderHistory($order_no, $customer_id, $user_id, $comment, $notify, $status, $platform);
//            $message_text = OrderModel::getOrderSMSText($name, $amount, $order_no);
//            Log::error(__CLASS__." :: ".__FUNCTION__." Message Text : $message_text");
//            if(!SMSModel::scheduleNewSMS($mobile, $message_text, 'PRODUCT ORDER', 'AUTO', $con))
//            {
//                Log::error(__CLASS__." :: ".__FUNCTION__." Error while sending SMS");
//            }
            return returnResponse("Your placed successfully !", HttpStatus::HTTP_OK, HttpStatus::HTTP_SUCCESS);
        }
        
        $payment_status = $status;
        self::update_transaction($customer_id, $customer_id, $order_id, $txnId, $status, $desc, $razorpay_payment_id);
        Orders::updateOrderStatus($customer_id, $customer_id, $order_id, $status, $payment_status);
        Log::error(__CLASS__." :: ".__FUNCTION__." Payment validation failed  for customer id $customer_id ");
        return returnResponse("Payment validation failed !!", HttpStatus::HTTP_ERROR);
    }
}
