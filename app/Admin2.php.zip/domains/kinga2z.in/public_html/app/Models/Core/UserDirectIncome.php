<?php

namespace App\Models\Core;

use Illuminate\Database\Eloquent\Model;

class UserDirectIncome extends Model
{
    //
}
