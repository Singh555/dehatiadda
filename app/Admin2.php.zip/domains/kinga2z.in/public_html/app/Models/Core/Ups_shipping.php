<?php

namespace App\Models\Core;;

use http\Env\Request;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
use Kyslik\ColumnSortable\Sortable;

class Ups_shipping extends Model
{
    //
    public function ups(){

    }
}
