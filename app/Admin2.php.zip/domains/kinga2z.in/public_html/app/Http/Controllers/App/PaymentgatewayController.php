<?php
namespace App\Http\Controllers\App;

use Illuminate\Routing\Controller;
use App\Models\AppModels\PaymentGatewayModel;
use Illuminate\Http\Request;

class PaymentgatewayController extends Controller
{
    
    public function validatePayment(Request $request)
    {
        return PaymentGatewayModel::validatePayment($request);
    }
    public function updatePaymentCanceled()
    {
        return PaymentGatewayModel::updatePaymentCanceled();
    }
}
