<?php
namespace App\Http\Controllers\App;

//use Mail;
//validator is builtin class in laravel
use App\Models\AppModels\Cart;
//for password encryption or hash protected
use App\Models\AppModels\Product;

//for authenitcate login data
use Carbon\Carbon;
use Illuminate\Support\Facades\Validator;
//for requesting a value
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use App\Helpers\HttpStatus;
//for Carbon a value
use DB;
use Log;
class CartController extends Controller
{


    //addToCart
    public function addToCart(Request $request)
    {
        $consumer_data = getallheaders();
      /*
      $consumer_data['consumer_key'] = $request->header('consumer_key');
      $consumer_data['consumer_secret'] = $request->header('consumer_secret');
      $consumer_data['consumer_nonce'] = $request->header('consumer_nonce');
      $consumer_data['consumer_device_id'] = $request->header('consumer_device_id');
      */
      $consumer_data['consumer_ip'] = $request->ip();
        $consumer_data['consumer_url'] = __FUNCTION__;
        $authController = new AppSettingController();
        $authenticate = $authController->apiAuthenticate($consumer_data);
        if ($authenticate == 1) {
            
            $validator = Validator::make($request->all(), [
            'quantity' => 'required|numeric|min:1',
            'products_id' => 'required',
            'attributes.*' => 'nullable',
            
            ]);
        
            if ($validator->fails()) {
                return returnResponse($validator->errors(), HttpStatus::HTTP_UNPROCESSABLE_ENTITY);
            }
            
         $inventory_ref_id = '';
      $result = array();
      $products_id = $request->input('products_id');
      $quantity = $request->input('quantity');
      $productsType = DB::table('products')->where('products_id', $products_id)->get();
      //check products type
      if ($productsType[0]->products_type == 1) {
          $attributes = array_filter($request->input('attributes'));
          $attributeid = implode(',', $attributes);

          $postAttributes = count($attributes);

          $inventories = DB::table('inventory')->where('products_id', $products_id)->get();
          $reference_ids = array();
          $stocks = 0;
          $stockIn = 0;
          foreach ($inventories as $inventory) {

              $totalAttribute = DB::table('inventory_detail')->where('inventory_detail.inventory_ref_id', '=', $inventory->inventory_ref_id)->get();
              $totalAttributes = count($totalAttribute);

              if ($postAttributes > $totalAttributes) {
                  $count = $postAttributes;
              } elseif ($postAttributes < $totalAttributes or $postAttributes == $totalAttributes) {
                  $count = $totalAttributes;
              }

              $individualStock = DB::table('inventory')->leftjoin('inventory_detail', 'inventory_detail.inventory_ref_id', '=', 'inventory.inventory_ref_id')
                  ->selectRaw('inventory.*')
                  ->whereIn('inventory_detail.attribute_id', [$attributeid])
                  ->where(DB::raw('(select count(*) from `inventory_detail` where `inventory_detail`.`attribute_id` in (' . $attributeid . ') and `inventory_ref_id`= "' . $inventory->inventory_ref_id . '")'), '=', $count)
                  ->where('inventory.inventory_ref_id', '=', $inventory->inventory_ref_id)
                  ->groupBy('inventory_detail.inventory_ref_id')
                  ->get();

              if (count($individualStock) > 0) {
                  $inventory_ref_id = $individualStock[0]->inventory_ref_id;
                  $stockIn += $individualStock[0]->stock;
              }

          }


          //orders products
          $orders_products = DB::table('orders_products')->where('products_id', $products_id)->get();
          $stockOut = 0;
          foreach ($orders_products as $orders_product) {
              $totalAttribute = DB::table('orders_products_attributes')->where('orders_products_id', '=', $orders_product->orders_products_id)->get();
              $totalAttributes = count($totalAttribute);

              if ($postAttributes > $totalAttributes) {
                  $count = $postAttributes;
              } elseif ($postAttributes < $totalAttributes or $postAttributes == $totalAttributes) {
                  $count = $totalAttributes;
              }
              $options_names = "1";
              $options_values = "1";
              $products = DB::select("select orders_products.* from `orders_products` left join `orders_products_attributes` on `orders_products_attributes`.`orders_products_id` = `orders_products`.`orders_products_id` where `orders_products`.`products_id`='" . $products_id . "' and `orders_products_attributes`.`products_options` in (" . $options_names . ") and `orders_products_attributes`.`products_options_values` in (" . $options_values . ") and (select count(*) from `orders_products_attributes` where `orders_products_attributes`.`products_id` = '" . $products_id . "' and `orders_products_attributes`.`products_options` in (" . $options_names . ") and `orders_products_attributes`.`products_options_values` in (" . $options_values . ") and `orders_products_attributes`.`orders_products_id`= '" . $orders_product->orders_products_id . "') = " . $count . " and `orders_products`.`orders_products_id` = '" . $orders_product->orders_products_id . "' group by `orders_products_attributes`.`orders_products_id`");

              if (count($products) > 0) {
                  $stockOut += $products[0]->products_quantity;
              }
          }
          $stocks = $stockIn - $stockOut;

      } else {

          $stocks = 0;

          $stocksin = DB::table('inventory')->where('products_id', $products_id)->where('stock_type', 'in')->sum('stock');
          $stockOut = DB::table('inventory')->where('products_id', $products_id)->where('stock_type', 'out')->sum('stock');
          $stocks = $stocksin - $stockOut;
      }
            if($stocks > $quantity){
               return returnResponse("Item Successfully added to cart", HttpStatus::HTTP_OK, HttpStatus::HTTP_SUCCESS, array('stocks'=>$stocks)); 
            }
           return returnResponse("Out of stock", HttpStatus::HTTP_NOT_ACCEPTABLE, HttpStatus::HTTP_WARNING); 

        }
        return returnResponse(HttpStatus::$text[HttpStatus::HTTP_UNAUTHORIZED], HttpStatus::HTTP_UNAUTHORIZED);
        
        
        
    }

    //addToCartFixed
    public function attributeDetails(Request $request)
    {
        $consumer_data = getallheaders();
      /*
      $consumer_data['consumer_key'] = $request->header('consumer_key');
      $consumer_data['consumer_secret'] = $request->header('consumer_secret');
      $consumer_data['consumer_nonce'] = $request->header('consumer_nonce');
      $consumer_data['consumer_device_id'] = $request->header('consumer_device_id');
      */
        $result = array();
      $consumer_data['consumer_ip'] = $request->ip();
        $consumer_data['consumer_url'] = __FUNCTION__;
        $authController = new AppSettingController();
        $authenticate = $authController->apiAuthenticate($consumer_data);
        if ($authenticate == 1) {
            
            $validator = Validator::make($request->all(), [
            'products_id' => 'required',
            'attribute_id.*' => 'required',
            
            ]);
        
            if ($validator->fails()) {
                return returnResponse($validator->errors(), HttpStatus::HTTP_UNPROCESSABLE_ENTITY);
            }
            $currentDate = time();
            $categories = DB::table('products')
                  ->leftJoin('manufacturers', 'manufacturers.manufacturers_id', '=', 'products.manufacturers_id')
                  ->leftJoin('manufacturers_info', 'manufacturers.manufacturers_id', '=', 'manufacturers_info.manufacturers_id')
                  ->leftJoin('products_description', 'products_description.products_id', '=', 'products.products_id')
                  ;
              $categories->LeftJoin('image_categories', function ($join) {
                  $join->on('image_categories.image_id', '=', 'products.products_image')
                      ->where(function ($query) {
                          $query->where('image_categories.image_type', '=', 'THUMBNAIL')
                              ->where('image_categories.image_type', '!=', 'THUMBNAIL')
                              ->orWhere('image_categories.image_type', '=', 'ACTUAL');
                      });
              })
               
              ;
              $categories->LeftJoin('specials', function ($join) use ($currentDate) {
                $join->on('specials.products_id', '=', 'products.products_id')->where('status', '=', '1')->where('expires_date', '>', $currentDate);
            });
              $categories->LeftJoin('flash_sale', function ($join) use ($currentDate) {
                $join->on('flash_sale.products_id', '=', 'products.products_id')->where('flash_sale.flash_status', '=', '1')->where('flash_expires_date', '>', $currentDate);
            });
            
                  $categories->where('products.products_id', '=', $request->products_id);
              $data = $categories->select('products.*', 'products_description.*', 'manufacturers.*', 'manufacturers_info.*', 'specials.specials_new_products_price as discount_price','flash_sale.flash_start_date', 'flash_sale.flash_expires_date', 'flash_sale.flash_sale_products_price as flash_price', 'image_categories.path as products_image')->first();
              //multiple images
                      $products_images = DB::table('products_images')
                          ->LeftJoin('image_categories', function ($join) {
                              $join->on('image_categories.image_id', '=', 'products_images.image')
                                  ->where(function ($query) {
                                      $query->where('image_categories.image_type', '=', 'THUMBNAIL')
                                          ->where('image_categories.image_type', '!=', 'THUMBNAIL')
                                          ->orWhere('image_categories.image_type', '=', 'ACTUAL');
                                  });
                          })
                          ->select('products_images.*', 'image_categories.path as image')
                          ->where('products_id', '=', $data->products_id)->orderBy('sort_order', 'ASC')->get();
                      $data->images = $products_images;
              if (!empty($data->flash_price)) {
                    $final_price = $data->flash_price + 0;
                    $data->discount_percent = 0;
                                            $data->discounted_price = 0;
                 } elseif (!empty($data->discount_price)) {
                     $final_price = $data->discount_price + 0;
                     $discount_price = $data->discount_price;
                                        
                                        
                                            $discounted_price = $data->products_price - $discount_price;
                                            $discount_percentage = $discounted_price / $data->products_price * 100;
                                            $data->discount_percent = intval($discount_percentage);
                                            $data->discounted_price = $discount_price;
                                        
                                        $data->discount_price = $discount_price;
                 } else {
                     $data->discount_percent = 0;
                                            $data->discounted_price = 0;
                     $final_price = $data->products_price + 0;
                 }
                 
                 $attributeArray = DB::table('products_attributes')->whereIn('products_attributes_id', $request->attribute_id)->get();
                 foreach ($attributeArray as $attribute) {
                     $symbol = $attribute->price_prefix;
                    $values_price = $attribute->options_values_price;
                    if ($symbol == '+') {
                        $final_price = intval($final_price) + intval($values_price);
                    }
                    if ($symbol == '-') {
                        $final_price = intval($final_price) - intval($values_price);
                    }
                 }
                    
                    
                    $qunatity['products_id'] = $request->products_id;
                    $qunatity['attributes'] =  $request->attribute_id;
                    
                    Log::debug('Attributes '.json_encode($request->attribute_id));

                    $content = Product::productQuantity($qunatity);
                    //dd($content);
                    $stocks = $content['remainingStock'];
         $data->stock = $stocks;
         $data->final_price = $final_price;
         $result['product_data'] = $data; 
         //$result['stock'] = $stocks;
         //$result['final_price'] = $final_price;
         
            
            
           return returnResponse("Product data!", HttpStatus::HTTP_OK, HttpStatus::HTTP_SUCCESS, $result);

        }
        return returnResponse(HttpStatus::$text[HttpStatus::HTTP_UNAUTHORIZED], HttpStatus::HTTP_UNAUTHORIZED);
    }

   

}
